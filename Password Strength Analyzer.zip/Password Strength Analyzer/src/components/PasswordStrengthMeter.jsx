import { useState } from "react";
import { analyzePassword } from "../utils/passwordStrength";

function getSecurityStatus(label) {
  if (label === "Very Weak" || label === "Weak") {
    return { text: "STATUS: AT RISK", color: "#f97373" };
  }
  if (label === "Medium") {
    return { text: "STATUS: NEEDS IMPROVEMENT", color: "#facc15" };
  }
  return { text: "STATUS: SECURE", color: "#22c55e" };
}

function PasswordStrengthMeter() {
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  const result = password ? analyzePassword(password) : null;
  const status = result ? getSecurityStatus(result.label) : null;

  const toggleShowPassword = () => {
    setShowPassword((prev) => !prev);
  };

  return (
    <div className="card">
      <label className="label">Password Input</label>

      <div className="password-wrapper">
        <input
          type={showPassword ? "text" : "password"}
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Type password to analyze..."
          className="input"
        />
        <button
          type="button"
          className="eye-button"
          onClick={toggleShowPassword}
        >
          {showPassword ? "🙈" : "👁️"}
        </button>
      </div>

      {result && (
        <div className="result">
          <p>
            <strong>Strength:</strong> {result.label}
          </p>
          <p>
            <strong>Score:</strong> {result.score}/5
          </p>

          {status && (
            <p
              style={{ fontSize: "12px", fontWeight: "bold", color: status.color }}
              className={
                result.label === "Very Weak" || result.label === "Weak"
                  ? "weak-flicker"
                  : ""
              }
            >
              {status.text}
            </p>
          )}

          <p style={{ fontSize: "11px", color: "#9ca3af" }}>
            Higher strength makes brute-force and guessing attacks significantly
            harder.
          </p>

          <div className="bar">
            <div
              className="bar-fill"
              style={{ width: `${(result.score / 5) * 100}%` }}
            />
          </div>

          <div className="gauge-labels">
            <span>0</span>
            <span>1</span>
            <span>2</span>
            <span>3</span>
            <span>4</span>
            <span>5</span>
          </div>

          {result.issues.length > 0 && (
            <>
              <h4>Recommendations</h4>
              <ul>
                {result.issues.map((item, i) => (
                  <li key={i}>{item}</li>
                ))}
              </ul>
            </>
          )}
        </div>
      )}
    </div>
  );
}

export default PasswordStrengthMeter;