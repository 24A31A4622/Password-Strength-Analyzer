const COMMON_PASSWORDS = [
  "password",
  "123456",
  "12345678",
  "qwerty",
  "111111",
  "123123",
  "abc123"
];

export function analyzePassword(password) {
  let score = 0;
  const issues = [];

  const hasLower = /[a-z]/.test(password);
  const hasUpper = /[A-Z]/.test(password);
  const hasDigit = /[0-9]/.test(password);
  const hasSymbol = /[^A-Za-z0-9]/.test(password);

  if (password.length >= 8) score++;
  else issues.push("Use at least 8 characters.");

  if (password.length >= 12) score++;

  if (hasLower && hasUpper) score++;
  else issues.push("Use both lowercase and uppercase letters.");

  if (hasDigit) score++;
  else issues.push("Add at least one number.");

  if (hasSymbol) score++;
  else issues.push("Add at least one symbol like @ or #.");

  if (COMMON_PASSWORDS.includes(password.toLowerCase())) {
    score = 0;
    issues.push("This password is too common.");
  }

  if (score > 5) score = 5;

  let label = "Very Weak";
  if (score === 2) label = "Weak";
  if (score === 3) label = "Medium";
  if (score === 4) label = "Strong";
  if (score >= 5) label = "Very Strong";

  return { score, label, issues };
}