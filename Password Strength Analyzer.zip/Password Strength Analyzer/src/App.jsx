import PasswordStrengthMeter from "./components/PasswordStrengthMeter";

const logLines = [
  "[INFO] Initializing PASSGUARD entropy engine...",
  "[INFO] Loading common-password blacklist...",
  "[OK]  Blacklist loaded. Monitoring input stream.",
  "[WARN] Short passwords are highly vulnerable to brute force.",
  "[HINT] Mix upper, lower, numbers & symbols for better entropy.",
  "[INFO] Estimating resistance to offline cracking attempts..."
];

function App() {
  return (
    <>
      <div className="shell">
        <div className="shell-left">
          <header className="header">
            <div className="header-title">[ PASSGUARD v1.0 ]</div>
            <div className="header-subtitle">
              Cybersecurity · Password Strength Analysis Console
            </div>
            <div className="header-status">
              MODE: <span className="header-status-live">ACTIVE SCAN</span>
            </div>
          </header>

          <PasswordStrengthMeter />
        </div>

        <div className="shell-right">
          <section className="panel panel-logs">
            <div className="panel-title">SYSTEM LOG</div>
            <div className="panel-body panel-body-logs">
              {logLines.map((line, i) => (
                <div key={i} className="log-line">
                  {line}
                </div>
              ))}
              <div className="log-cursor">_</div>
            </div>
          </section>

          <section className="panel panel-help">
            <div className="panel-title">SECURITY HINTS</div>
            <div className="panel-body">
              <ul className="hint-list">
                <li>Use 12+ characters whenever possible.</li>
                <li>Avoid using personal info or common words.</li>
                <li>Each site should have a unique password.</li>
                <li>
                  Use a password manager to store complex secrets securely.
                </li>
              </ul>
            </div>
          </section>
        </div>
      </div>

      <div className="scan-overlay" />
    </>
  );
}

export default App;